<!-- Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('id', 'Id:') !!}
    {!! Form::text('id', null, ['class' => 'form-control']) !!}
</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('name', 'Name:') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<!-- Rgba Color Field -->
<div class="form-group col-sm-6">
    {!! Form::label('rgba_color', 'Rgba Color:') !!}
    {!! Form::text('rgba_color', null, ['class' => 'form-control']) !!}
</div>