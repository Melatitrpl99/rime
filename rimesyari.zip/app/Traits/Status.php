<?php

trait Status {

    public function setStatus($status) {

    }
}
