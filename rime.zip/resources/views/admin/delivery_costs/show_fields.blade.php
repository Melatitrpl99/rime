<!-- Name Field -->
<div class="form-group row">
    <div class="col-12 col-md-3 text-bold">Name:</div>
    <div class="col-12 col-md-9">{{ $deliveryCost->name }}</div>
</div>

<!-- Harga Field -->
<div class="form-group row">
    <div class="col-12 col-md-3 text-bold">Harga:</div>
    <div class="col-12 col-md-9">{{ $deliveryCost->harga }}</div>
</div>

<!-- Jarak Field -->
<div class="form-group row">
    <div class="col-12 col-md-3 text-bold">Jarak:</div>
    <div class="col-12 col-md-9">{{ $deliveryCost->jarak }}</div>
</div>

<!-- Created At Field -->
<div class="form-group row">
    <div class="col-12 col-md-3 text-bold">Created At:</div>
    <div class="col-12 col-md-9">{{ $deliveryCost->created_at }}</div>
</div>

<!-- Updated At Field -->
<div class="form-group row">
    <div class="col-12 col-md-3 text-bold">Updated At:</div>
    <div class="col-12 col-md-9">{{ $deliveryCost->updated_at }}</div>
</div>

