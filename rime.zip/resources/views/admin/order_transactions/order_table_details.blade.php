<table class="table table-sm table-borderless table-striped" id="order_detail-table" style="min-width: 1024px">
    <thead>
        <tr>
            <th class="py-2 border-bottom" width="50">#</th>
            <th class="py-2 border-bottom">Varian produk</th>
            <th class="py-2 border-bottom text-right" width="150">Harga</th>
            <th class="py-2 border-bottom text-right" width="50">Jumlah</th>
            <th class="py-2 border-bottom text-right" width="150">Diskon</th>
            <th class="py-2 border-bottom text-right" width="160">Subtotal</th>
        </tr>
    </thead>
    <tbody id="order_details_tbody">
    </tbody>
    <tfoot>
        <th class="py-2 border-top" colspan="2"></th>
        <th class="py-2 border-top text-right">Total</th>
        <th class="py-2 border-top text-right" id="order_details_jumlah"></th>
        <th class="py-2 border-top text-right" id="order_details_diskon"></th>
        <th class="py-2 border-top text-right" id="order_details_total"></th>
    </tfoot>
</table>
