@push('css')
<!-- Tempus Dominus Bootstrap4 -->
<link rel="stylesheet" href="{{ asset('adminlte/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}">
@endpush

@push('scripts')
<!-- Moment.js -->
<script src="{{ asset('adminlte/plugins/moment/moment.min.js') }}"></script>
<!-- Tempus Dominus Bootstrap4 -->
<script src="{{ asset('adminlte/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js') }}"></script>
@endpush
