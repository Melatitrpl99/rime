<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700&display=swap">
<!-- Font Awesome Icons -->
<link rel="stylesheet" href="{{ asset('adminlte/plugins/fontawesome-free/css/all.min.css') }}">
<!-- Theme style -->
<link rel="stylesheet" href="{{ asset('adminlte/dist/css/adminlte.min.css') }}">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="{{ asset('adminlte/plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">

<style>
    body {
        font-family: 'Roboto';
    }

    .py-0\.5 {
        padding-top: 0.125rem !important;
        padding-bottom: 0.125rem !important;
    }

    a:hover + i, a + i:hover {
        visibility: visible;
    }

    a + i {
        visibility: hidden;
    }
</style>
@stack('css')