<?php

namespace App\Http\Controllers\API\Misc;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GetUserShipmentAddressFieldController extends Controller
{
    //
}
