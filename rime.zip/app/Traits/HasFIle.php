<?php

namespace App\Models;

trait HasFIle
{
    //
}
